const mysql = require('mysql');

const Connection = mysql.createConnection({
    host: 'localhost',
    user: 'roque',
    password: '',
    database: 'movies-controll'
})

module.exports = Connection;
